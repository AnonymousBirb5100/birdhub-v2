(function() {
    let script = document.createElement("script");
    script.async = true;
    script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7321073664976914";
    script.crossOrigin = "anonymous";
    document.head.appendChild(script);
})();