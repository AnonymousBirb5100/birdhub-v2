function YYGGames () {
  this.showSplash = function (data= null) {
  }
  this.startupByYad= function (obj) {
  }
}
YYGGames= new YYGGames();
