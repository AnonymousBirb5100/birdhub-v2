FB= {
  "login": function() {
  }
}
