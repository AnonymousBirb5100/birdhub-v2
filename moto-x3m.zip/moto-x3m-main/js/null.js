// H2Fixed

console.log("NullJS");